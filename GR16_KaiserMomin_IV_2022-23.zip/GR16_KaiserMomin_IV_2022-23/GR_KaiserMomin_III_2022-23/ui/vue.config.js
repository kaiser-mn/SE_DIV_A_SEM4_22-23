module.exports = {
    lintOnSave: false
  }